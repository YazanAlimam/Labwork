﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Y_1._0_
{
    class Student
    {
        public string SurName { get; set; }
        public string Name { get; set; }
        public List<double> work = new List<double>();
        public double final { get; set; }

    }
}
