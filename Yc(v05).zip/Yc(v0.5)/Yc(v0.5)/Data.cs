﻿using System;    
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Yc_v0._5_
{
    class Data
    {
        public List<Student> s = new List<Student>();
        public LinkedList<Student> ls = new LinkedList<Student>();
        public Queue<Student> qs = new Queue<Student>();
        public void add(Student a)
        {
            s.Add(a);
        }
        public void addLinked(Student a)
        {
            ls.AddLast(a);
        }
        public void addQueue(Student a)
        {
            qs.Enqueue(a);
        }

        public void addDequeue(Student a)
        {
            s.Add(a);
        }
        public void display()
        {
            Compar hy = new Compar();
            s.Sort(hy);
            Console.WriteLine("SurName".PadRight(25) + "Name".PadRight(25) + "Final Point Avg".PadLeft(20) + "Final Point Med".PadLeft(20));
            for (int i = 0; i < 90; i++)
            {
                Console.Write('-');
            }
            Console.WriteLine();
            foreach (var sd in s)
            {
                double num = 0.0;
                double count = 0.0;
                foreach (var g in sd.work)
                {
                    try
                    {
                        num = num + g;
                        count++;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                }
                try
                {

                    num = num / count;
                    Math.Round(num, 1);
                    sd.final = (sd.final + num) / 2;
                    Math.Round(sd.final, 1);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
                Console.WriteLine(sd.SurName.PadRight(25) + sd.Name.PadRight(25) + num.ToString().PadLeft(20) + sd.final.ToString().PadLeft(20));
            }


        }
        public void distribute(Data s2, Data s3)
        {
            var watch = new System.Diagnostics.Stopwatch();


            watch.Start();


            foreach (var sd in s)
            {
                double num = 0.0;
                double count = 0.0;
                foreach (var g in sd.work)
                {
                    try
                    {
                        num = num + g;
                        count++;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                }
                try
                {

                    if (count == 0)
                    { count = 1; }

                    num = num / count;
                    Math.Round(num, 1);
                    sd.final = (sd.final + num) / 2;
                    sd.final = Math.Round(sd.final, 1);
                    if ((0.3 * num + 0.7 * sd.final) >= 5)
                    { s2.add(sd); }
                    else { s3.add(sd); }


                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }

            }
            watch.Stop();



            Console.WriteLine($"Execution Time For Spliting  Data into to list  : {watch.ElapsedMilliseconds} ms");



        }
        public void distributeLinkedList(Data s2, Data s3)
        {
            var watch = new System.Diagnostics.Stopwatch();

           


           
            watch.Start();


            foreach (var sd in ls)
            {
                double num = 0.0;
                double count = 0.0;
                foreach (var g in sd.work)
                {
                    try
                    {
                        num = num + g;
                        count++;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                }
                try
                {

                    if (count == 0)
                    { count = 1; }

                    num = num / count;
                    Math.Round(num, 1);
                    sd.final = (sd.final + num) / 2;
                    sd.final = Math.Round(sd.final, 1);
                    if ((0.3 * num + 0.7 * sd.final) >= 5)
                    { s2.add(sd); }
                    else { s3.add(sd); }


                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }

            }
            watch.Stop();



            Console.WriteLine($"Execution Time For Spliting  Data into to list  : {watch.ElapsedMilliseconds} ms");



        }
        public void distributeQueue(Data s2, Data s3)
        {
            var watch = new System.Diagnostics.Stopwatch();





            watch.Start();


            foreach (var sd in qs)
            {
                double num = 0.0;
                double count = 0.0;
                foreach (var g in sd.work)
                {
                    try
                    {
                        num = num + g;
                        count++;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                }
                try
                {

                    if (count == 0)
                    { count = 1; }

                    num = num / count;
                    Math.Round(num, 1);
                    sd.final = (sd.final + num) / 2;
                    sd.final = Math.Round(sd.final, 1);
                    if ((0.3 * num + 0.7 * sd.final) >= 5)
                    { s2.add(sd); }
                    else { s3.add(sd); }


                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }

            }
            watch.Stop();



            Console.WriteLine($"Execution Time For Spliting  Data into to list  : {watch.ElapsedMilliseconds} ms");



        }

    }
}    
